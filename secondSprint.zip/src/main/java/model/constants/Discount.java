package model.constants;

public class Discount {
    public static final double DEFAULT_DISCOUNT = 0;
    public static final double RED_APPLES = 60;
}